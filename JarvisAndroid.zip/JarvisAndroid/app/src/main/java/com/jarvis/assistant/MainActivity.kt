package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var coreButton: ImageButton
    private lateinit var coreLabel: TextView
    private lateinit var statusText: TextView
    private lateinit var logContainer: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var textInput: EditText
    private lateinit var sendBtn: Button
    private lateinit var settingsBtn: ImageButton

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var router: CommandRouter? = null

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_FINE_LOCATION
    )

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { /* results handled implicitly; SpeechRecognizer checks again before use */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        coreButton = findViewById(R.id.coreButton)
        coreLabel = findViewById(R.id.coreLabel)
        statusText = findViewById(R.id.statusText)
        logContainer = findViewById(R.id.logContainer)
        logScroll = findViewById(R.id.logScroll)
        textInput = findViewById(R.id.textInput)
        sendBtn = findViewById(R.id.sendBtn)
        settingsBtn = findViewById(R.id.settingsBtn)

        tts = TextToSpeech(this, this)
        router = CommandRouter(this)

        requestNeededPermissions()
        promptEnableAccessibilityIfNeeded()

        addMessage("Systems online. How can I help?", isUser = false)

        coreButton.setOnClickListener { startListening() }
        sendBtn.setOnClickListener {
            val text = textInput.text.toString()
            textInput.setText("")
            if (text.isNotBlank()) handleCommand(text)
        }
        settingsBtn.setOnClickListener { showSettingsDialog() }
    }

    // ---------------- Permissions ----------------
    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    private fun promptEnableAccessibilityIfNeeded() {
        if (JarvisAccessibilityService.instance == null) {
            AlertDialog.Builder(this)
                .setTitle("One-time setup")
                .setMessage("For Jarvis to lock the screen or go Home on command, enable its Accessibility Service once in Android Settings.")
                .setPositiveButton("Open Settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    private fun showSettingsDialog() {
        val input = EditText(this)
        input.hint = "Anthropic API key (sk-ant-...)"
        input.setText(Prefs.getApiKey(this) ?: "")
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setMessage("Enter your Anthropic API key. Get one at console.anthropic.com")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                Prefs.setApiKey(this, input.text.toString().trim())
                Toast.makeText(this, "Saved.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- Voice ----------------
    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this device.", Toast.LENGTH_SHORT).show()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("LISTENING") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { setStatus("PROCESSING") }
            override fun onError(error: Int) { setStatus("STANDBY") }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()
                setStatus("STANDBY")
                if (!text.isNullOrBlank()) handleCommand(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    private fun handleCommand(text: String) {
        addMessage(text, isUser = true)
        setStatus("PROCESSING")
        lifecycleScope.launch {
            val reply = router?.route(text) ?: "Something went wrong."
            addMessage(reply, isUser = false)
            speak(reply)
        }
    }

    private fun speak(text: String) {
        setStatus("SPEAKING")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt")
        setStatus("STANDBY")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
        }
    }

    // ---------------- UI helpers ----------------
    private fun setStatus(state: String) {
        statusText.text = state
        coreLabel.text = when (state) {
            "LISTENING" -> "LISTENING..."
            "PROCESSING" -> "THINKING..."
            "SPEAKING" -> "RESPONDING..."
            else -> "TAP CORE TO SPEAK"
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        val tv = TextView(this)
        tv.text = (if (isUser) "YOU: " else "JARVIS: ") + text
        tv.setTextColor(if (isUser) 0xFFE8F4F8.toInt() else 0xFF4FD8EF.toInt())
        tv.textSize = 14f
        tv.setPadding(0, 8, 0, 8)
        logContainer.addView(tv)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
