package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var coreButton: ImageButton
    private lateinit var coreLabel: TextView
    private lateinit var statusText: TextView
    private lateinit var logContainer: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var textInput: EditText
    private lateinit var sendBtn: Button
    private lateinit var settingsBtn: ImageButton

    private lateinit var enrollBtn: Button
    private lateinit var bgToggleBtn: Button

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var router: CommandRouter? = null

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.POST_NOTIFICATIONS
    )

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { /* results handled implicitly; SpeechRecognizer checks again before use */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        coreButton = findViewById(R.id.coreButton)
        coreLabel = findViewById(R.id.coreLabel)
        statusText = findViewById(R.id.statusText)
        logContainer = findViewById(R.id.logContainer)
        logScroll = findViewById(R.id.logScroll)
        textInput = findViewById(R.id.textInput)
        sendBtn = findViewById(R.id.sendBtn)
        settingsBtn = findViewById(R.id.settingsBtn)
        enrollBtn = findViewById(R.id.enrollBtn)
        bgToggleBtn = findViewById(R.id.bgToggleBtn)

        tts = TextToSpeech(this, this)
        router = CommandRouter(this)

        requestNeededPermissions()
        promptEnableAccessibilityIfNeeded()

        addMessage("Systems online. How can I help?", isUser = false)

        coreButton.setOnClickListener { startListening() }
        sendBtn.setOnClickListener {
            val text = textInput.text.toString()
            textInput.setText("")
            if (text.isNotBlank()) handleCommand(text)
        }
        settingsBtn.setOnClickListener { showSettingsDialog() }
        enrollBtn.setOnClickListener { startEnrollment() }
        bgToggleBtn.setOnClickListener { toggleBackgroundListening() }
        refreshBgButtonLabel()
    }

    override fun onResume() {
        super.onResume()
        refreshBgButtonLabel()
    }

    private fun refreshBgButtonLabel() {
        bgToggleBtn.text = if (WillListenerService.isRunning) "STOP BACKGROUND" else "START BACKGROUND"
    }

    private fun toggleBackgroundListening() {
        if (WillListenerService.isRunning) {
            stopService(Intent(this, WillListenerService::class.java))
            addMessage("Background listening stopped.", isUser = false)
        } else {
            if (!SpeakerVerification.hasEnrolledProfile(this)) {
                Toast.makeText(this, "Enroll your voice first (button above).", Toast.LENGTH_LONG).show()
                return
            }
            if (Prefs.getPicovoiceKey(this).isNullOrBlank()) {
                Toast.makeText(this, "Add your Picovoice access key in Settings first.", Toast.LENGTH_LONG).show()
                return
            }
            val intent = Intent(this, WillListenerService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            addMessage("Background listening started — I'll only respond to your voice now, even with the app closed.", isUser = false)
        }
        bgToggleBtn.postDelayed({ refreshBgButtonLabel() }, 500)
    }

    private fun startEnrollment() {
        if (Prefs.getPicovoiceKey(this).isNullOrBlank()) {
            Toast.makeText(this, "Add your Picovoice access key in Settings first (it's free).", Toast.LENGTH_LONG).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions()
            return
        }

        val progressDialog = AlertDialog.Builder(this)
            .setTitle("Enrolling your voice")
            .setMessage("Speak naturally for about 10–20 seconds — read a sentence, count numbers, anything. 0%")
            .setCancelable(false)
            .create()
        progressDialog.show()

        lifecycleScope.launch {
            val success = VoiceEnrollment.enroll(this@MainActivity) { pct ->
                runOnUiThread {
                    progressDialog.setMessage("Speak naturally... $pct%")
                }
            }
            progressDialog.dismiss()
            if (success) {
                addMessage("Voice enrolled! I'll now only respond to you.", isUser = false)
            } else {
                addMessage("Enrollment failed — check your Picovoice key in Settings and try again somewhere quiet.", isUser = false)
            }
        }

    // ---------------- Permissions ----------------
    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    private fun promptEnableAccessibilityIfNeeded() {
        if (JarvisAccessibilityService.instance == null) {
            AlertDialog.Builder(this)
                .setTitle("One-time setup")
                .setMessage("For Will to lock the screen or go Home on command, enable its Accessibility Service once in Android Settings.")
                .setPositiveButton("Open Settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    private fun showSettingsDialog() {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 20, 50, 20)

        val claudeLabel = TextView(this)
        claudeLabel.text = "Anthropic API key (for general chat & news — paid, but cheap)"
        claudeLabel.textSize = 12f
        val claudeInput = EditText(this)
        claudeInput.hint = "sk-ant-..."
        claudeInput.setText(Prefs.getApiKey(this) ?: "")

        val weatherLabel = TextView(this)
        weatherLabel.text = "OpenWeatherMap API key (for weather — 100% free)"
        weatherLabel.textSize = 12f
        weatherLabel.setPadding(0, 30, 0, 0)
        val weatherInput = EditText(this)
        weatherInput.hint = "your free key here"
        weatherInput.setText(Prefs.getWeatherKey(this) ?: "")

        val picovoiceLabel = TextView(this)
        picovoiceLabel.text = "Picovoice access key (for voice matching — free tier)"
        picovoiceLabel.textSize = 12f
        picovoiceLabel.setPadding(0, 30, 0, 0)
        val picovoiceInput = EditText(this)
        picovoiceInput.hint = "your Picovoice AccessKey"
        picovoiceInput.setText(Prefs.getPicovoiceKey(this) ?: "")

        layout.addView(claudeLabel)
        layout.addView(claudeInput)
        layout.addView(weatherLabel)
        layout.addView(weatherInput)
        layout.addView(picovoiceLabel)
        layout.addView(picovoiceInput)

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setMessage("Claude: console.anthropic.com\nWeather (free): home.openweathermap.org/users/sign_up\nPicovoice (free): console.picovoice.ai")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                Prefs.setApiKey(this, claudeInput.text.toString().trim())
                Prefs.setWeatherKey(this, weatherInput.text.toString().trim())
                Prefs.setPicovoiceKey(this, picovoiceInput.text.toString().trim())
                Toast.makeText(this, "Saved.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- Voice ----------------
    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this device.", Toast.LENGTH_SHORT).show()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("LISTENING") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { setStatus("PROCESSING") }
            override fun onError(error: Int) { setStatus("STANDBY") }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()
                setStatus("STANDBY")
                if (!text.isNullOrBlank()) handleCommand(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    private fun handleCommand(text: String) {
        addMessage(text, isUser = true)
        setStatus("PROCESSING")
        lifecycleScope.launch {
            val reply = router?.route(text) ?: "Something went wrong."
            addMessage(reply, isUser = false)
            speak(reply)
        }
    }

    private fun speak(text: String) {
        setStatus("SPEAKING")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt")
        setStatus("STANDBY")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
        }
    }

    // ---------------- UI helpers ----------------
    private fun setStatus(state: String) {
        statusText.text = state
        coreLabel.text = when (state) {
            "LISTENING" -> "LISTENING..."
            "PROCESSING" -> "THINKING..."
            "SPEAKING" -> "RESPONDING..."
            else -> "TAP CORE TO SPEAK"
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        val tv = TextView(this)
        tv.text = (if (isUser) "YOU: " else "WILL: ") + text
        tv.setTextColor(if (isUser) 0xFFE8F4F8.toInt() else 0xFF4FD8EF.toInt())
        tv.textSize = 14f
        tv.setPadding(0, 8, 0, 8)
        logContainer.addView(tv)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
