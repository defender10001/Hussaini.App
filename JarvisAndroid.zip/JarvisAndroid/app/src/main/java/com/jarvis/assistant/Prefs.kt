package com.jarvis.assistant

import android.content.Context

object Prefs {
    private const val FILE = "jarvis_prefs"
    private const val KEY_API = "anthropic_api_key"

    fun getApiKey(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_API, null)

    fun setApiKey(context: Context, key: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_API, key).apply()
    }
}
