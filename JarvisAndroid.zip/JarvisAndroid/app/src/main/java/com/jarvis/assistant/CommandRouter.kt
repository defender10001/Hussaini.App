package com.jarvis.assistant

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.telephony.SmsManager

/**
 * Excluded on purpose: any payment / banking / UPI app. This app never
 * requests those packages and CommandRouter refuses to launch them even
 * if asked, as a safety guardrail.
 */
private val BLOCKED_KEYWORDS = listOf(
    "gpay", "google pay", "phonepe", "paytm", "bhim", "upi",
    "bank", "amazon pay", "cred", "paypal"
)

private val APP_PACKAGES = mapOf(
    "whatsapp" to "com.whatsapp",
    "instagram" to "com.instagram.android",
    "youtube" to "com.google.android.youtube",
    "chrome" to "com.android.chrome",
    "gmail" to "com.google.android.gm",
    "maps" to "com.google.android.apps.maps",
    "spotify" to "com.spotify.music",
    "facebook" to "com.facebook.katana",
    "twitter" to "com.twitter.android",
    "x" to "com.twitter.android",
    "camera" to "com.android.camera",
    "settings" to "com.android.settings",
    "telegram" to "org.telegram.messenger",
    "netflix" to "com.netflix.mediaclient",
)

class CommandRouter(private val activity: Activity) {

    private val audioManager by lazy { activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    /** Returns a spoken-style reply for the given command. */
    suspend fun route(rawCommand: String): String {
        val c = rawCommand.lowercase().trim()
        if (c.isEmpty()) return ""

        if (BLOCKED_KEYWORDS.any { c.contains(it) }) {
            return "I'm not authorized to open payment or banking apps, for your safety."
        }

        // --- Lock screen / turn screen off ---
        if (Regex("lock( the)? (screen|phone)|screen off|phone off|turn off").containsMatchIn(c)) {
            val svc = JarvisAccessibilityService.instance
            return if (svc != null && svc.lockScreen()) {
                "Locking the screen now."
            } else {
                "I need Accessibility permission enabled in Settings to do that."
            }
        }

        // --- Wake / turn screen on ---
        if (Regex("wake( up)?|turn on( the)? screen|unlock").containsMatchIn(c)) {
            wakeScreen()
            return if (c.contains("unlock")) {
                "Screen is on — swipe or use your fingerprint to unlock, I can't bypass that for security."
            } else {
                "Waking the screen."
            }
        }

        // --- Open app ---
        if (c.startsWith("open ") || c.startsWith("launch ") || c.startsWith("start ")) {
            val target = c.replace(Regex("^(open|launch|start) "), "").trim()
            return openApp(target)
        }

        // --- Volume ---
        if (c.contains("volume up") || c.contains("increase volume")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            return "Volume up."
        }
        if (c.contains("volume down") || c.contains("decrease volume")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return "Volume down."
        }
        if (c.contains("mute")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            return "Muted."
        }

        // --- Flashlight ---
        if (c.contains("flashlight") || c.contains("torch")) {
            val on = !c.contains("off")
            return toggleFlashlight(on)
        }

        // --- WiFi / Bluetooth (Android 10+ requires the panel, apps can't silently toggle) ---
        if (c.contains("wifi") || c.contains("wi-fi")) {
            activity.startActivity(Intent(Settings.Panel.ACTION_WIFI))
            return "Opening Wi-Fi settings."
        }
        if (c.contains("bluetooth")) {
            activity.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            return "Opening connectivity settings."
        }

        // --- Call ---
        if (c.startsWith("call ")) {
            val number = c.removePrefix("call ").trim()
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
            activity.startActivity(intent)
            return "Calling $number."
        }

        // --- SMS ---
        if (c.startsWith("text ") || c.startsWith("message ")) {
            return "Tell me the number and message, like: text 9999999999 saying I'm on my way."
        }

        // --- Home / Recents / Notifications ---
        if (c.contains("go home") || c == "home") {
            JarvisAccessibilityService.instance?.goHome()
            return "Going home."
        }
        if (c.contains("recent apps") || c.contains("app switcher")) {
            JarvisAccessibilityService.instance?.openRecents()
            return "Opening recent apps."
        }
        if (c.contains("notifications")) {
            JarvisAccessibilityService.instance?.openNotifications()
            return "Opening notifications."
        }

        // --- News / weather -> Claude with web search (checked BEFORE date, since
        // phrases like "weather today" or "today's news" contain "today") ---
        if (c.contains("news") || c.contains("weather")) {
            return ClaudeClient.ask(activity, rawCommand, useWebSearch = true)
        }

        // --- Time / date ---
        if (c.contains("time")) {
            val time = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
            return "It's $time."
        }
        if (c.contains("date") || c.contains("today")) {
            val date = java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
            return "Today is $date."
        }

        // --- Fallback: general conversation ---
        return ClaudeClient.ask(activity, rawCommand, useWebSearch = false)
    }

    private fun openApp(target: String): String {
        val pkg = APP_PACKAGES.entries.firstOrNull { target.contains(it.key) }?.value
        if (pkg != null) {
            val intent = activity.packageManager.getLaunchIntentForPackage(pkg)
            return if (intent != null) {
                activity.startActivity(intent)
                "Opening $target."
            } else {
                "$target isn't installed on this phone."
            }
        }
        // Fallback: try treating it as a web search
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$target"))
        activity.startActivity(intent)
        return "I don't have a direct link for $target, so I searched it instead."
    }

    private fun wakeScreen() {
        val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
            "jarvis:wake"
        )
        wl.acquire(3000)
    }

    private fun toggleFlashlight(on: Boolean): String {
        return try {
            val cm = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This device doesn't have a flashlight."
            cm.setTorchMode(camId, on)
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "Couldn't control the flashlight: ${e.message}"
        }
    }
}
