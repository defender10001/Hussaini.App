package com.jarvis.assistant

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.telephony.SmsManager

/**
 * Excluded on purpose: any payment / banking / UPI app. This app never
 * requests those packages and CommandRouter refuses to launch them even
 * if asked, as a safety guardrail.
 */
private val BLOCKED_KEYWORDS = listOf(
    "gpay", "google pay", "phonepe", "paytm", "bhim", "upi",
    "bank", "amazon pay", "cred", "paypal"
)

// (App list is now looked up dynamically from every installed app — see openApp() below.)

class CommandRouter(private val context: Context) {

    private val audioManager by lazy { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    /** Returns a spoken-style reply for the given command, in any language. */
    suspend fun route(rawCommand: String): String {
        val c = rawCommand.lowercase().trim()
        if (c.isEmpty()) return ""

        if (BLOCKED_KEYWORDS.any { c.contains(it) }) {
            return "I'm not authorized to open payment or banking apps, for your safety."
        }

        // 1) Try matching known action patterns directly (English + common Hindi/Hinglish).
        matchAction(c, rawCommand)?.let { return it }

        // 2) Not matched — could be a different language (Chinese, pure Hindi script, etc).
        //    Translate to English and try matching again before treating it as a general question.
        val apiKey = Prefs.getApiKey(activity)
        if (!apiKey.isNullOrBlank() && !isLikelyEnglish(c)) {
            val translated = ClaudeClient.translateToEnglish(activity, rawCommand)
            if (!translated.isNullOrBlank()) {
                matchAction(translated.lowercase().trim(), rawCommand)?.let { return it }
            }
        }

        // 3) Fallback: general conversation — Claude answers in whatever language was asked.
        return ClaudeClient.ask(activity, rawCommand, useWebSearch = false)
    }

    /** Rough heuristic: does this look like it's already English/Latin-script? */
    private fun isLikelyEnglish(c: String): Boolean = c.all { it.code < 128 }

    /** Tries every known action pattern. Returns null if nothing matched (not an error). */
    private suspend fun matchAction(c: String, rawCommand: String): String? {
        // --- End / cut a call (not possible for any regular app — see note) ---
        if (Regex("cut( the)? call|end( the)? call|hang ?up|call kaato|kaat do|disconnect( the)? call").containsMatchIn(c)) {
            return "I can't end a call — only the phone's default Dialer app is allowed to do that, and Android blocks every other app from it for security. Sorry, that one's a hard limit."
        }

        // --- Call a contact / number ---
        if (Regex("^(call|dial|phone|ring)\\s|call karo|call lagao|milao|milaao").containsMatchIn(c)) {
            val target = c.replace(Regex("call karo|call lagao|milaao|milao|^(call|dial|phone|ring)\\s"), "").trim()
            return placeCall(target)
        }

        // --- Lock screen / turn screen off ---
        if (Regex("lock( the)? (screen|phone)|screen off|phone off|turn off|screen band|phone band|lock karo").containsMatchIn(c)) {
            val svc = JarvisAccessibilityService.instance
            return if (svc != null && svc.lockScreen()) {
                "Locking the screen now."
            } else {
                "I need Accessibility permission enabled in Settings to do that."
            }
        }

        // --- Wake / turn screen on ---
        if (Regex("wake( up)?|turn on( the)? screen|unlock|jagao|screen on karo").containsMatchIn(c)) {
            wakeScreen()
            return if (c.contains("unlock")) {
                "Screen is on — swipe or use your fingerprint to unlock, I can't bypass that for security."
            } else {
                "Waking the screen."
            }
        }

        // --- Close current app / go home ---
        if (Regex("close (this|the) app|cut (this|the) app|go home|^home$|band karo|is app ko band").containsMatchIn(c)) {
            JarvisAccessibilityService.instance?.goHome()
            return "Closing it — back to home screen."
        }

        // --- Open app ---
        if (Regex("^(open|launch|start)\\s|khol|chalu karo").containsMatchIn(c)) {
            val target = c.replace(Regex("^(open|launch|start)\\s|khol\\w*|chalu karo"), "").trim()
            return openApp(target)
        }

        // --- Volume ---
        if (Regex("volume up|increase volume|awaaz badhao|volume badhao").containsMatchIn(c)) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            return "Volume up."
        }
        if (Regex("volume down|decrease volume|awaaz kam karo|volume kam karo").containsMatchIn(c)) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return "Volume down."
        }
        if (c.contains("mute")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            return "Muted."
        }

        // --- Flashlight ---
        if (Regex("flashlight|torch").containsMatchIn(c)) {
            val on = !Regex("off|band karo").containsMatchIn(c)
            return toggleFlashlight(on)
        }

        // --- WiFi / Bluetooth (Android 10+ requires the panel, apps can't silently toggle) ---
        if (c.contains("wifi") || c.contains("wi-fi")) {
            activity.startActivity(Intent(Settings.Panel.ACTION_WIFI))
            return "Opening Wi-Fi settings."
        }
        if (c.contains("bluetooth")) {
            activity.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            return "Opening connectivity settings."
        }

        // --- SMS ---
        if (c.startsWith("text ") || c.startsWith("message ")) {
            return "Tell me the number and message, like: text 9999999999 saying I'm on my way."
        }

        // --- Recents / Notifications ---
        if (c.contains("recent apps") || c.contains("app switcher")) {
            JarvisAccessibilityService.instance?.openRecents()
            return "Opening recent apps."
        }
        if (c.contains("notifications")) {
            JarvisAccessibilityService.instance?.openNotifications()
            return "Opening notifications."
        }

        // --- News -> Claude with web search ---
        if (Regex("news|khabar|samachar").containsMatchIn(c)) {
            return ClaudeClient.ask(activity, rawCommand, useWebSearch = true)
        }

        // --- Weather -> real GPS location + FREE OpenWeatherMap lookup
        // (checked BEFORE date, since phrases like "weather today" contain "today") ---
        if (Regex("weather|mausam").containsMatchIn(c)) {
            val place = LocationHelper.currentPlaceName(activity)
            return WeatherClient.getWeather(activity, place)
        }

        // --- Time / date ---
        if (Regex("time|samay|kitne baje").containsMatchIn(c)) {
            val time = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
            return "It's $time."
        }
        if (Regex("date|today|tareekh|aaj").containsMatchIn(c)) {
            val date = java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
            return "Today is $date."
        }

        return null // no action matched — caller will treat this as a general question
    }

    private fun placeCall(target: String): String {
        if (target.isBlank()) return "Who should I call?"

        // If it's already a phone number, dial it directly.
        if (target.replace(Regex("[\\s+-]"), "").all { it.isDigit() } && target.any { it.isDigit() }) {
            activity.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$target")))
            return "Calling $target."
        }

        // Otherwise, look it up in Contacts.
        if (ActivityCompatPermissionCheck.has(activity, android.Manifest.permission.READ_CONTACTS)) {
            val match = ContactHelper.findNumber(activity, target)
            if (match != null) {
                val (contactName, number) = match
                activity.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
                return "Calling $contactName."
            }
            return "I couldn't find \"$target\" in your contacts."
        }
        return "I need Contacts permission to call people by name — grant it in Settings, or say a phone number instead."
    }

    private fun openApp(target: String): String {
        val pm = activity.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val installedApps = pm.queryIntentActivities(launcherIntent, 0)

        // Try exact / contains match on the app's visible name (e.g. "WhatsApp", "Camera")
        val cleanTarget = target.trim().lowercase()
        val match = installedApps
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .firstOrNull { (_, label) ->
                val l = label.lowercase()
                l == cleanTarget || l.contains(cleanTarget) || cleanTarget.contains(l)
            }

        if (match != null) {
            val (pkg, label) = match
            val intent = pm.getLaunchIntentForPackage(pkg)
            return if (intent != null) {
                activity.startActivity(intent)
                "Opening $label."
            } else {
                "Found $label but couldn't launch it."
            }
        }

        // Fallback: try treating it as a web search
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$target"))
        activity.startActivity(intent)
        return "I couldn't find an app called \"$target\" on this phone, so I searched it instead."
    }

    private fun wakeScreen() {
        val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
            "jarvis:wake"
        )
        wl.acquire(3000)
    }

    private fun toggleFlashlight(on: Boolean): String {
        return try {
            val cm = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This device doesn't have a flashlight."
            cm.setTorchMode(camId, on)
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "Couldn't control the flashlight: ${e.message}"
        }
    }
}
