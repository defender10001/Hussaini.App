package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to the Anthropic Claude API. Requires the user to have entered
 * their own API key in Settings (stored in SharedPreferences).
 *
 * Get a key at https://console.anthropic.com
 */
object ClaudeClient {

    suspend fun ask(context: android.content.Context, question: String, useWebSearch: Boolean): String {
        val apiKey = Prefs.getApiKey(context)
        if (apiKey.isNullOrBlank()) {
            return "I need an Anthropic API key to answer that. Add one in Settings."
        }

        return withContext(Dispatchers.IO) {
            try {
                val url = URL("https://api.anthropic.com/v1/messages")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("x-api-key", apiKey)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                conn.setRequestProperty("content-type", "application/json")
                conn.doOutput = true

                val body = JSONObject().apply {
                    put("model", "claude-sonnet-4-6")
                    put("max_tokens", 400)
                    put(
                        "system",
                        "You are JARVIS, a witty, concise voice assistant like in Iron Man. " +
                        "Reply in 2-4 short spoken-style sentences. Match the user's language " +
                        "(Hindi/Hinglish/English) to how they asked."
                    )
                    put("messages", JSONArray().put(
                        JSONObject().put("role", "user").put("content", question)
                    ))
                    if (useWebSearch) {
                        put("tools", JSONArray().put(
                            JSONObject().put("type", "web_search_20250305").put("name", "web_search")
                        ))
                    }
                }

                conn.outputStream.use { it.write(body.toString().toByteArray()) }

                val responseCode = conn.responseCode
                val stream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
                val text = stream.bufferedReader().use { it.readText() }

                if (responseCode !in 200..299) {
                    return@withContext "API error ($responseCode). Check your key in Settings."
                }

                val json = JSONObject(text)
                val content = json.optJSONArray("content") ?: return@withContext "No response received."
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val block = content.getJSONObject(i)
                    if (block.optString("type") == "text") {
                        sb.append(block.optString("text"))
                    }
                }
                if (sb.isEmpty()) "I couldn't process that." else sb.toString()
            } catch (e: Exception) {
                "I couldn't connect right now: ${e.message}"
            }
        }
    }
}
