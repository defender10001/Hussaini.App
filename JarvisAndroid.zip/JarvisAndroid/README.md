# JARVIS — Native Android Assistant

A real Android app (not a browser demo) that listens to your voice and takes
actions on your phone: opens apps, locks/wakes the screen, controls
flashlight/volume, makes calls, answers questions via Claude AI (with news/weather
via web search) — all through a tap-to-talk HUD interface.

**Payment/banking apps (GPay, PhonePe, Paytm, etc.) are hard-blocked in code** —
the app will refuse to open them even if asked, on purpose.

---

## ⚠️ What this CANNOT do (read this first — it's an OS limit, not a bug)

- **Turn on a phone that is completely powered off.** No software runs when
  the phone is off — this needs the physical power button, always.
- **Unlock the screen (bypass PIN/fingerprint) without you.** Android
  deliberately blocks every app, including this one, from dismissing the
  lock screen without your credentials. Jarvis can *lock* the screen and
  *wake* the display, but the final swipe/PIN/fingerprint is always yours.
- **Always-listening in the background with the screen off.** This build is
  tap-to-talk (you open the app, tap the core, speak). A true 24/7 wake-word
  listener needs a persistent foreground service + wake-word engine
  (e.g., Picovoice Porcupine) and drains battery — happy to add it as a v2
  if you want, but it's a separate, heavier project.

---

## What it CAN do
- Open any installed app by name: *"open whatsapp"*, *"open camera"*
- Lock the screen: *"lock screen"* / Wake it: *"wake up"*
- Volume, flashlight, WiFi/Bluetooth panel
- Call a number: *"call 9876543210"*
- Tell time/date
- News & weather (via Claude + live web search)
- General conversation — ask it anything

---

## STEP 1 — Install Android Studio
Download from https://developer.android.com/studio (free). Install with
default settings — it bundles the Android SDK you need.

## STEP 2 — Open this project
1. Unzip the folder you downloaded from Claude.
2. Open Android Studio → **Open** → select the unzipped `JarvisAndroid` folder.
3. Let it sync (first time takes a few minutes — it downloads Gradle + SDK
   components automatically, needs internet).

## STEP 3 — Connect your phone
1. On your phone: **Settings → About phone → tap "Build number" 7 times**
   (enables Developer Options).
2. **Settings → Developer options → turn on USB debugging.**
3. Plug phone into your laptop with a USB cable, tap "Allow" on the phone
   when prompted.

## STEP 4 — Run it
In Android Studio, click the green ▶️ **Run** button, choose your phone from
the device list. It'll install and launch automatically.

## STEP 5 — One-time permissions on the phone
The app will ask for: Microphone, Call, SMS, Camera — tap **Allow** on each.

It will also prompt you once to open **Accessibility Settings** — turn on
the "Jarvis" toggle there. This is what lets it lock the screen / go home on
command. (Android requires this to be a manual, explicit step — no app can
skip it, for your security.)

## STEP 6 — Add your Claude API key
Tap the ⚙️ icon top-right → paste your key from
https://console.anthropic.com (free to create, pay-as-you-go pricing) →
Save. This powers news, weather, and general conversation.

---

## Try it
Tap the glowing core and say things like:
- "Open Instagram"
- "Lock the screen"
- "What's the weather today"
- "Tell me the news"
- "Call 9876543210"
- "Turn on flashlight"
- Or just ask it anything — "explain black holes in one line"

---

## Customizing
- **Add more apps**: edit `APP_PACKAGES` in `CommandRouter.kt` — add the
  app name and its Android package ID (find package IDs by searching
  "[app name] package name android" or checking the Play Store URL).
- **Add more blocked apps**: edit `BLOCKED_KEYWORDS` in `CommandRouter.kt`.
- **Change the voice/wording**: edit the `system` prompt in `ClaudeClient.kt`.

## Troubleshooting
- **"App not installed" for something you have** → the package ID in
  `APP_PACKAGES` might not match your device's version; check the real
  package name and update it.
- **Accessibility actions not working** → re-check Settings → Accessibility
  → Jarvis is still toggled on (Android sometimes disables it after
  updates).
- **Gradle sync fails** → make sure you're connected to the internet the
  first time you open the project (it downloads build tools).
