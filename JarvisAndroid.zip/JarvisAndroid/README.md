# JARVIS — Native Android Assistant

A real Android app (not a browser demo) that listens to your voice and takes
actions on your phone: opens apps, locks/wakes the screen, controls
flashlight/volume, makes calls, answers questions via Claude AI (with news/weather
via web search) — all through a tap-to-talk HUD interface.

**Payment/banking apps (GPay, PhonePe, Paytm, etc.) are hard-blocked in code** —
the app will refuse to open them even if asked, on purpose.

---

## ⚠️ What this CANNOT do (read this first — it's an OS limit, not a bug)

- **Turn on a phone that is completely powered off.** No software runs when
  the phone is off — this needs the physical power button, always.
- **Unlock the screen (bypass PIN/fingerprint) without you.** Android
  deliberately blocks every app, including this one, from dismissing the
  lock screen without your credentials. Jarvis can *lock* the screen and
  *wake* the display, but the final swipe/PIN/fingerprint is always yours.
- **Always-listening in the background with the screen off.** This build is
  tap-to-talk (you open the app, tap the core, speak). A true 24/7 wake-word
  listener needs a persistent foreground service + wake-word engine
  (e.g., Picovoice Porcupine) and drains battery — happy to add it as a v2
  if you want, but it's a separate, heavier project.

---

## What it CAN do
- Open any installed app by name: *"open whatsapp"*, *"open camera"*, *"camera khol do"*
- Lock the screen: *"lock screen"* / Wake it: *"wake up"*
- Close current app / go home: *"close this app"*, *"home"*
- Volume, flashlight, WiFi/Bluetooth panel
- **Call any contact by name OR a raw number**: *"call Mummy"*, *"call 9876543210"*
- Tell time/date (uses your phone's own time zone — always accurate, no setup needed)
- **Real weather for where you actually are** (uses GPS + live web search)
- News (via Claude + live web search)
- General conversation — ask it anything, **in any language** (English, Hindi, Chinese, etc. — commands get auto-translated if needed)
- **Runs fully in the background** — no need to open the app or tap anything
- **Only responds to YOUR enrolled voice** — ignores other people talking near it (see setup below)

## What it still CANNOT do (Android hard limits — no app can do these)
- **End/cut, or auto-answer, an ongoing call.** Only the phone's default
  Dialer app has this power; Android blocks every other app from it,
  permanently, for security. (You said you'll handle calls yourself — good
  call, this is why.)
- **Turn on a phone that's completely powered off**, or **unlock the screen
  without your PIN/fingerprint.**
- **Perfectly detect a recorded voice vs. your real live voice.** Voice
  *matching* (is this the enrolled person?) works well. Reliably telling a
  good recording of you apart from the real you is a much harder,
  research-grade problem — even bank-grade voice biometrics don't fully
  solve it. Treat this as "keeps casual/accidental triggers from other
  people out," not as a security lock.

---

## Setting up background listening + voice matching (optional but powerful)

This uses **Picovoice Eagle**, a speaker-recognition SDK with a free
personal tier.

1. Go to https://console.picovoice.ai, sign up (free).
2. Copy your **AccessKey** from the dashboard.
3. In the Will app → ⚙️ Settings → paste it into **"Picovoice access key"** → Save.
4. Tap **"ENROLL VOICE"** on the main screen. Speak naturally for ~10–20
   seconds (read anything — a sentence, count numbers) until it hits 100%.
5. Tap **"START BACKGROUND"**. You'll see a permanent notification (Android
   requires this — it's how you know your mic is active) saying "Will is
   listening." From now on, just talk near your phone — no tapping needed.
6. To stop, tap **"STOP BACKGROUND"** in the app, or "Stop" on the notification.

**Important — background listening reliability:**
- Some phone brands (Xiaomi/MIUI, Oppo, Vivo, OnePlus, Realme) aggressively
  kill background apps to save battery. If Will stops responding after a
  while, go to **Settings → Battery → App battery saver → find "Will"** and
  set it to **unrestricted / no restrictions**, and enable **"Autostart"**
  if your phone has that setting.
- The very first word of a command can occasionally get clipped, because
  the mic briefly switches modes when it recognizes your voice. If a
  command doesn't register, just repeat it.
- This is a genuinely advanced feature — if `eagle-android` fails to
  resolve in Gradle, check the current version at
  https://github.com/Picovoice/eagle and update the version number in
  `app/build.gradle.kts`.

---

## STEP 1 — Install Android Studio
Download from https://developer.android.com/studio (free). Install with
default settings — it bundles the Android SDK you need.

## STEP 2 — Open this project
1. Unzip the folder you downloaded from Claude.
2. Open Android Studio → **Open** → select the unzipped `JarvisAndroid` folder.
3. Let it sync (first time takes a few minutes — it downloads Gradle + SDK
   components automatically, needs internet).

## STEP 3 — Connect your phone
1. On your phone: **Settings → About phone → tap "Build number" 7 times**
   (enables Developer Options).
2. **Settings → Developer options → turn on USB debugging.**
3. Plug phone into your laptop with a USB cable, tap "Allow" on the phone
   when prompted.

## STEP 4 — Run it
In Android Studio, click the green ▶️ **Run** button, choose your phone from
the device list. It'll install and launch automatically.

## STEP 5 — One-time permissions on the phone
The app will ask for: Microphone, Call, SMS, Camera, **Contacts** (for calling
people by name), and **Location** (for real local weather) — tap **Allow**
on each.

It will also prompt you once to open **Accessibility Settings** — turn on
the "Jarvis" toggle there. This is what lets it lock the screen / go home on
command. (Android requires this to be a manual, explicit step — no app can
skip it, for your security.)

## STEP 6 — Add your API keys
Tap the ⚙️ icon top-right — you'll see two fields:

- **Weather key (100% FREE, no card ever)**: go to
  https://home.openweathermap.org/users/sign_up on your phone, sign up,
  then go to your account → **API keys** tab → copy the default key shown
  there. Paste it in. *(New keys can take 10–60 minutes to activate — if
  weather fails right after signing up, just try again a bit later.)*

- **Claude key (for general chat & news — has a cost, but very cheap)**:
  from https://console.anthropic.com. New accounts get some free trial
  credit; after that it's pay-as-you-go, typically fractions of a cent
  per question. **You can skip this entirely if you only want weather,
  apps, calling, and the built-in commands — everything except general
  Q&A and news will still work for free.**

---

## Try it
Tap the glowing core and say things like:
- "Open Instagram"
- "Lock the screen"
- "What's the weather today"
- "Tell me the news"
- "Call 9876543210"
- "Turn on flashlight"
- Or just ask it anything — "explain black holes in one line"

---

## Customizing
- **Add more apps**: edit `APP_PACKAGES` in `CommandRouter.kt` — add the
  app name and its Android package ID (find package IDs by searching
  "[app name] package name android" or checking the Play Store URL).
- **Add more blocked apps**: edit `BLOCKED_KEYWORDS` in `CommandRouter.kt`.
- **Change the voice/wording**: edit the `system` prompt in `ClaudeClient.kt`.

## Troubleshooting
- **"App not installed" for something you have** → the package ID in
  `APP_PACKAGES` might not match your device's version; check the real
  package name and update it.
- **Accessibility actions not working** → re-check Settings → Accessibility
  → Jarvis is still toggled on (Android sometimes disables it after
  updates).
- **Gradle sync fails** → make sure you're connected to the internet the
  first time you open the project (it downloads build tools).
