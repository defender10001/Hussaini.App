package com.jarvis.assistant

import android.content.Context
import android.provider.ContactsContract

object ContactHelper {

    /** Returns the phone number for the best-matching contact name, or null. */
    fun findNumber(context: Context, name: String): Pair<String, String>? {
        val query = name.trim()
        if (query.isEmpty()) return null

        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null

        var best: Pair<String, String>? = null
        cursor.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val contactName = it.getString(nameIdx) ?: continue
                val number = it.getString(numIdx) ?: continue
                if (contactName.equals(query, ignoreCase = true)) {
                    return contactName to number // exact match wins immediately
                }
                if (best == null && contactName.contains(query, ignoreCase = true)) {
                    best = contactName to number
                }
            }
        }
        return best
    }
}
