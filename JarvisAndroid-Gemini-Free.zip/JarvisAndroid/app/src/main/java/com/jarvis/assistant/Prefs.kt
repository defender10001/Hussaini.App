package com.jarvis.assistant

import android.content.Context

object Prefs {
    private const val FILE = "jarvis_prefs"
    private const val KEY_API = "gemini_api_key"
    private const val KEY_WEATHER = "openweathermap_api_key"

    fun getApiKey(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_API, null)

    fun setApiKey(context: Context, key: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_API, key).apply()
    }

    fun getWeatherKey(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_WEATHER, null)

    fun setWeatherKey(context: Context, key: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_WEATHER, key).apply()
    }

    private const val KEY_PICOVOICE = "picovoice_access_key"
    private const val KEY_VOICE_PROFILE = "eagle_voice_profile_b64"

    fun getPicovoiceKey(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_PICOVOICE, null)

    fun setPicovoiceKey(context: Context, key: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_PICOVOICE, key).apply()
    }

    fun getVoiceProfile(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_VOICE_PROFILE, null)

    fun setVoiceProfile(context: Context, base64Profile: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_VOICE_PROFILE, base64Profile).apply()
    }

    fun clearVoiceProfile(context: Context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .remove(KEY_VOICE_PROFILE).apply()
    }
}
