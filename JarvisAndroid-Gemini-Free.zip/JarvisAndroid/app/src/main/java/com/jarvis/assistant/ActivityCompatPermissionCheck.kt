package com.jarvis.assistant

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

object ActivityCompatPermissionCheck {
    fun has(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
