package com.jarvis.assistant

import ai.picovoice.eagle.Eagle
import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.util.Locale
import kotlin.math.abs

/**
 * Runs continuously in the background. Uses Eagle to check "is this the
 * owner's voice?" on live mic audio. Only when it recognizes YOUR voice
 * speaking (not silence, not someone else) does it hand off to Android's
 * SpeechRecognizer to transcribe the actual command and execute it.
 *
 * Reliability notes (please read):
 * - Android requires a persistent notification for any app listening to the
 *   mic in the background — this is not optional, by design, for privacy.
 * - Some phone brands (Xiaomi, Oppo, Vivo, etc.) aggressively kill background
 *   services to save battery. If this stops working after a while, go to
 *   Settings → Battery → find "Will" → disable battery optimization / allow
 *   background activity for it.
 * - Because the mic briefly hands off from raw capture to SpeechRecognizer,
 *   the very first word of your command can occasionally get clipped.
 *   Speaking a beat before your actual request helps.
 */
class WillListenerService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "will_listener_channel"
        const val NOTIF_ID = 42
        const val ACTION_STOP = "com.jarvis.assistant.STOP_LISTENING"
        var isRunning = false
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var eagle: Eagle? = null
    private var recorder: AudioRecord? = null
    private var listening = true
    private var tts: TextToSpeech? = null
    private var router: CommandRouter? = null

    private val MATCH_THRESHOLD = 0.6f   // tune up/down based on false accepts/rejects
    private val SILENCE_LEVEL = 500      // rough amplitude threshold for "someone is talking"

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        tts = TextToSpeech(this, this)
        router = CommandRouter(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification("Listening for your voice..."))
        startEagleLoop()
        return START_STICKY
    }

    private fun startEagleLoop() {
        eagle = SpeakerVerification.newVerifier(applicationContext)
        val eagleInstance = eagle
        if (eagleInstance == null) {
            updateNotification("Setup incomplete — enroll your voice in the app first.")
            stopSelf()
            return
        }

        serviceScope.launch {
            try {
                val sampleRate = eagleInstance.sampleRate
                val frameLength = eagleInstance.frameLength
                val bufferSize = AudioRecord.getMinBufferSize(
                    sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )

                @Suppress("MissingPermission")
                recorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC, sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(bufferSize, frameLength * 4)
                )
                recorder?.startRecording()

                val frame = ShortArray(frameLength)
                var consecutiveMatches = 0

                while (listening) {
                    val rec = recorder ?: break
                    val read = rec.read(frame, 0, frame.size)
                    if (read != frame.size) continue

                    val avgAmplitude = frame.map { abs(it.toInt()) }.average()
                    if (avgAmplitude < SILENCE_LEVEL) {
                        consecutiveMatches = 0
                        continue // silence — nothing to check
                    }

                    val scores = eagleInstance.process(frame)
                    val myScore = scores.firstOrNull() ?: 0f

                    if (myScore >= MATCH_THRESHOLD) {
                        consecutiveMatches++
                    } else {
                        consecutiveMatches = 0
                    }

                    // Require a short sustained match before triggering, to
                    // avoid firing on a single noisy frame.
                    if (consecutiveMatches >= 3) {
                        consecutiveMatches = 0
                        handleWakeDetected()
                    }
                }
            } catch (e: Exception) {
                updateNotification("Listener error: ${e.message}")
            }
        }
    }

    /** Pauses raw capture, runs a real STT pass to get the command, executes it, then resumes. */
    private fun handleWakeDetected() {
        recorder?.stop()
        updateNotification("Heard you — listening for command...")

        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                sr.destroy()
                resumeRawCapture()
            }
            override fun onResults(results: android.os.Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                sr.destroy()
                if (!text.isNullOrBlank()) {
                    serviceScope.launch {
                        updateNotification("Working on: $text")
                        val reply = router?.route(text) ?: ""
                        if (reply.isNotBlank()) {
                            tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "will_bg")
                        }
                        updateNotification("Listening for your voice...")
                        resumeRawCapture()
                    }
                } else {
                    resumeRawCapture()
                }
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        sr.startListening(intent)
    }

    private fun resumeRawCapture() {
        recorder?.startRecording()
    }

    override fun onDestroy() {
        listening = false
        recorder?.stop()
        recorder?.release()
        eagle?.delete()
        tts?.shutdown()
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    // ---------------- Notification plumbing (required for a foreground service) ----------------
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Will — background listening", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, WillListenerService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Will is listening")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(0, "Stop", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIF_ID, buildNotification(text))
    }
}
