package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Free weather lookup via OpenWeatherMap (no credit card needed for the free tier).
 * Get a key at https://home.openweathermap.org/users/sign_up — the "free" plan
 * on the API keys page is enough (1,000 calls/day at no cost).
 */
object WeatherClient {

    suspend fun getWeather(context: android.content.Context, place: String?): String {
        val apiKey = Prefs.getWeatherKey(context)
        if (apiKey.isNullOrBlank()) {
            return "I need a free OpenWeatherMap API key to check real weather. Add one in Settings — it takes 2 minutes and never costs anything."
        }
        val city = place ?: return "I couldn't figure out your location. Try saying the city name, like \"weather in Mumbai\"."

        return withContext(Dispatchers.IO) {
            try {
                val encodedCity = URLEncoder.encode(city, "UTF-8")
                val url = URL("https://api.openweathermap.org/data/2.5/weather?q=$encodedCity&appid=$apiKey&units=metric")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"

                val responseCode = conn.responseCode
                val stream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
                val text = stream.bufferedReader().use { it.readText() }

                if (responseCode !in 200..299) {
                    return@withContext "Couldn't get weather for $city — double-check your API key in Settings, or that the key has finished activating (can take a few minutes after signup)."
                }

                val json = JSONObject(text)
                val main = json.getJSONObject("main")
                val temp = main.getDouble("temp")
                val feelsLike = main.getDouble("feels_like")
                val weatherArr = json.getJSONArray("weather")
                val description = weatherArr.getJSONObject(0).getString("description")

                "It's currently ${temp.toInt()}°C in $city, feels like ${feelsLike.toInt()}°C, with $description."
            } catch (e: Exception) {
                "I couldn't reach the weather service: ${e.message}"
            }
        }
    }
}
