package com.jarvis.assistant

import ai.picovoice.eagle.Eagle
import ai.picovoice.eagle.EagleException
import ai.picovoice.eagle.EagleProfile
import ai.picovoice.eagle.EagleProfiler
import android.content.Context
import android.util.Base64

/**
 * Wraps Picovoice Eagle for speaker verification: "only respond to MY voice."
 *
 * NOTE: exact Eagle method names below follow Picovoice's standard Android SDK
 * pattern (same as Porcupine/Cheetah/Rhino). If a compile error mentions a
 * missing method, check the current API at https://picovoice.ai/docs/api/eagle-android/
 * and adjust — the SDK may have changed slightly since this was written.
 */
object SpeakerVerification {

    fun hasEnrolledProfile(context: Context): Boolean = Prefs.getVoiceProfile(context) != null

    fun clearProfile(context: Context) = Prefs.clearVoiceProfile(context)

    /** Loads the saved profile as raw bytes, or null if not enrolled yet. */
    fun loadProfileBytes(context: Context): ByteArray? {
        val b64 = Prefs.getVoiceProfile(context) ?: return null
        return Base64.decode(b64, Base64.NO_WRAP)
    }

    fun saveProfile(context: Context, profile: EagleProfile) {
        val b64 = Base64.encodeToString(profile.bytes, Base64.NO_WRAP)
        Prefs.setVoiceProfile(context, b64)
    }

    /** Creates a fresh profiler for the enrollment flow (call .delete() on it when done). */
    fun newProfiler(context: Context): EagleProfiler? {
        val key = Prefs.getPicovoiceKey(context) ?: return null
        return try {
            EagleProfiler.Builder()
                .setAccessKey(key)
                .build(context)
        } catch (e: EagleException) {
            null
        }
    }

    /** Creates an Eagle verifier loaded with the saved profile, or null if not set up. */
    fun newVerifier(context: Context): Eagle? {
        val key = Prefs.getPicovoiceKey(context) ?: return null
        val bytes = loadProfileBytes(context) ?: return null
        return try {
            Eagle.Builder()
                .setAccessKey(key)
                .setSpeakerProfiles(arrayOf(EagleProfile(bytes)))
                .build(context)
        } catch (e: EagleException) {
            null
        }
    }
}
