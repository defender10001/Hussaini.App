package com.jarvis.assistant

import android.content.Context
import android.location.Geocoder
import android.location.LocationManager
import java.util.Locale

object LocationHelper {

    /** Best-effort city/area name from the device's last known location. */
    fun currentPlaceName(context: Context): String? {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            var location: android.location.Location? = null
            for (provider in providers) {
                val loc = lm.getLastKnownLocation(provider) ?: continue
                if (location == null || loc.accuracy < (location?.accuracy ?: Float.MAX_VALUE)) {
                    location = loc
                }
            }
            val loc = location ?: return null

            @Suppress("DEPRECATION")
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
            val address = addresses?.firstOrNull() ?: return null
            address.locality ?: address.subAdminArea ?: address.adminArea
        } catch (e: Exception) {
            null
        }
    }
}
