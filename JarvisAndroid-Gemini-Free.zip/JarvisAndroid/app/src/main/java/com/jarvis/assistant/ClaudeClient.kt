package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini API client.
 * The object keeps its old name so the rest of the Jarvis code does not need
 * to change. Users enter a Gemini API key in Settings.
 */
object ClaudeClient {

    private const val MODEL = "gemini-3.6-flash"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private fun makeRequest(apiKey: String, systemInstruction: String, userText: String, maxTokens: Int): JSONObject {
        val contents = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userText)))
            }
        )

        return JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            })
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", maxTokens)
                put("temperature", 0.7)
            })
        }
    }

    private fun extractText(json: JSONObject): String? {
        val candidates = json.optJSONArray("candidates") ?: return null
        val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return null
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
        }
        return sb.toString().trim().ifBlank { null }
    }

    private fun call(apiKey: String, body: JSONObject): Pair<Int, String> {
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("x-goog-api-key", apiKey)
            setRequestProperty("content-type", "application/json")
            connectTimeout = 20_000
            readTimeout = 60_000
            doOutput = true
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        return code to text
    }

    /** Translate short voice commands before local action matching. */
    suspend fun translateToEnglish(context: android.content.Context, text: String): String? {
        val apiKey = Prefs.getApiKey(context)
        if (apiKey.isNullOrBlank()) return null
        return withContext(Dispatchers.IO) {
            try {
                val body = makeRequest(
                    apiKey,
                    "Translate the user's short voice command into English. Output ONLY the translated command, nothing else — no quotes, no explanation.",
                    text,
                    60
                )
                val (code, response) = call(apiKey, body)
                if (code !in 200..299) return@withContext null
                extractText(JSONObject(response))
            } catch (_: Exception) {
                null
            }
        }
    }

    suspend fun ask(context: android.content.Context, question: String, useWebSearch: Boolean): String {
        val apiKey = Prefs.getApiKey(context)
        if (apiKey.isNullOrBlank()) {
            return "I need a Gemini API key to answer that. Add your free key in Settings."
        }

        return withContext(Dispatchers.IO) {
            try {
                val system = "You are Will, a witty, concise voice assistant like in Iron Man. " +
                    "Reply in 2-4 short spoken-style sentences. Match the user's language " +
                    "(Hindi/Hinglish/English) to how they asked. " +
                    if (useWebSearch) "The user asked for news/current information; clearly say when you cannot verify live information." else ""

                val body = makeRequest(apiKey, system, question, 400)
                val (code, response) = call(apiKey, body)
                if (code !in 200..299) {
                    val detail = try {
                        JSONObject(response).optJSONObject("error")?.optString("message")
                    } catch (_: Exception) { null }
                    return@withContext "Gemini API error ($code). ${detail ?: "Check your API key and free-tier quota in Settings."}"
                }

                extractText(JSONObject(response)) ?: "I couldn't process that."
            } catch (e: Exception) {
                "I couldn't connect right now: ${e.message ?: "network error"}"
            }
        }
    }
}
