package com.jarvis.assistant

import ai.picovoice.eagle.EagleProfiler
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object VoiceEnrollment {

    /**
     * Records short bursts from the mic and feeds them to Eagle until enrollment
     * reaches 100%. Calls onProgress(0..100) as it goes. Returns true on success.
     */
    suspend fun enroll(
        context: Context,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val profiler = SpeakerVerification.newProfiler(context) ?: return@withContext false

        try {
            val sampleRate = profiler.sampleRate
            val frameLength = profiler.minEnrollSamples // frames needed per enroll() call, per Eagle docs
            val bufferSize = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )

            @Suppress("MissingPermission")
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(bufferSize, frameLength * 2)
            )

            recorder.startRecording()
            var percentage = 0f
            val frame = ShortArray(frameLength)

            // Keep feeding audio until Eagle reports enrollment is complete.
            var attempts = 0
            while (percentage < 100f && attempts < 300) { // safety cap ~ a minute or two
                val read = recorder.read(frame, 0, frame.size)
                if (read == frame.size) {
                    val result = profiler.enroll(frame)
                    percentage = result.percentage
                    onProgress(percentage.toInt())
                }
                attempts++
            }

            recorder.stop()
            recorder.release()

            if (percentage >= 100f) {
                val profile = profiler.export()
                SpeakerVerification.saveProfile(context, profile)
                profiler.delete()
                true
            } else {
                profiler.delete()
                false
            }
        } catch (e: Exception) {
            profiler.delete()
            false
        }
    }
}
